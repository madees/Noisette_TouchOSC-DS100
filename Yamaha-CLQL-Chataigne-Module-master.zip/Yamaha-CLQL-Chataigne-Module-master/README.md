# Yamaha-CLQL-Chataigne-Module
Chataigne module for control of Yamaha CL/QL-series consoles
